<template>
  <div class="article-view">
    <h1>Artículo Individual</h1>
    <p>Contenido del artículo...</p>
  </div>
</template>

<script>
export default {
  name: 'ArticleView',
}
</script>

<style scoped>
.article-view {
  padding: 20px;
}
</style>
