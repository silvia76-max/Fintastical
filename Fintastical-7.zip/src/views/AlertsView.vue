<template>
  <div class="alerts-view">
    <h1>Configuración de Alertas</h1>
    <p>Aquí se podrán configurar alertas personalizadas.</p>

    </div>
</template>

<script setup>


</script>

<style scoped>
.alerts-view {
  padding: 20px;
}
</style>
