<template>
  <div>
    <NewsList />
  </div>
</template>

<script setup>
import NewsList from '@/components/news/NewsList.vue';
</script>
