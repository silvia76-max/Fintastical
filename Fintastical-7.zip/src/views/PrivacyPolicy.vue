<template>
  <div class="privacy-container">
 
   <h1>Privacy Policy</h1>
    <p><strong>Last Updated:</strong> June 2022</p>
    <p>This privacy policy (the “Policy“) explains how the Fintastical group (collectively “Fintastical“, “we” or “us” and each member of the Fintastical group for whose services you registered, the “Fintastical Entity“) collects, uses and discloses personal information through its websites, mobile applications, and other online products and services that link to this Policy, including any of the products and services detailed in the following paragraph (collectively, the “Services“) or when you otherwise interact with us.</p>
    <p>The Services include providing: (i) the Fintastical social trading platform for investing in stocks & EFTs, cryptocurrencies and for CFDs trading which users can sign up for an account with ; (ii) the Fintastical Money App which facilitates the Fintastical Money services (e-money account servicing payments and debit card) and Fintastical Money Crypto Wallet services; (iii) Fintastical X Digital Assets Exchange Services; (iv) any other site, web platform, mobile application or other service facilitated by any Fintastical Entity (any account described in (i)-(iv) being an “Fintastical Account” for the purpose of this Policy).</p>
    <p>We encourage you to read the Policy carefully as it forms part of the relevant Fintastical Entity’s terms and conditions, terms of business, agreement with you and/or terms of use, as the case may be.</p>
    <p>If you accept or agree to this Policy on behalf of a company or other legal entity, you represent and warrant that you have the authority to bind that company or other legal entity to the Privacy Policy and, in such event, “you” and “your” will refer and apply to that company or other legal entity.</p>

    <h2>Application of this Policy</h2>
    <p>For the purposes of applicable state and/or international data protection laws, the respective Fintastical Entity with whom you have registered is the “controller” of personal information collected through .wpengine.com (http://Fintastical.wpengine.com), other Fintastical group entities’ websites, widgets, mobile applications (including the Fintastical Money App) and other platforms (together the “Site”), and is the company to contact if you have questions about the use of your personal information (see the “Contact Us” section below). The Policy also applies to personal data about each authorized representative of a client and about other persons or entities where this personal data is collected in the course of providing the Services (such as directors of corporate clients).</p>

    <h2>Collection of Information</h2>
    <h3>Information You Provide to Us</h3>
    <p>We collect information you provide directly to us. For example, we collect information when you create an Fintastical Account, participate in any interactive features of the Services, fill out a form, participate in a contest or promotion, make a purchase, communicate with us via third party social media sites, request customer support, or otherwise communicate with us.</p>

    <h4>When You Sign Up or Register for an Fintastical Account or Services</h4>
    <p>If you sign up for an Fintastical Account or other Services, we will collect basic information about you including your name, email address and telephone number. You may provide this information to us directly, or by signing in to your account/service with a third party, including without limitation, Facebook or Google (see “Information We Collect from Other Sources” below). We will use the information that we collect about you to:</p>
    <ul>
        <li>Create and maintain your Fintastical Account;</li>
        <li>Allow you to log in to Fintastical;</li>
        <li>Contact you about your Fintastical Account and/or our Services (this may include marketing emails).</li>
    </ul>

    <h4>When You Provide Information to Build Your Profile</h4>
    <p>Once you have created an Fintastical Account, we will ask you to provide additional information to allow you to make use of certain functions. We will ask you to provide a copy of an identification document, such as a passport, residency permit, visa or national identity card, a utility bill and such other documents as may be required by us in order to comply with our regulatory obligations and to verify your identity. Further details about the identification process can be found in the relevant Fintastical Entity’s terms and conditions, terms of business and/or terms of use or client/customer agreement, as the case may be.</p>
    <p>Please note that if you choose to provide additional information about yourself to complete your “Profile“, then the information we ask for may include your gender, date of birth, place of birth, addresses, nationality, national insurance number, social security number (or other government issued identification number), citizenship and residency status, Tax ID, and information about your experience trading, education, source of income, investment aims and appetite, occupation, employer and employment position, annual income, investment portfolio, total cash and liquid assets and other details or questions as may be required in the Profile creation and the process may be amended by us from time to time.</p>
    <p>It is optional for you to do so but for legal and regulatory reasons you will be unable to proceed to use certain features unless you provide further information.</p>
    <p>We will use the information you provide in your Profile to:</p>
    <ul>
        <li>verify your identity and carry out checks that we are required to conduct by applicable laws and regulations, including without limitation, “know your customer” (KYC), anti-money laundering, fraud, sanctions and politically exposed person (PEP) checks;</li>
        <li>contact you on matters related to your Fintastical Account, including to request any additional information or documentation;</li>
        <li>provide you with notices related to your Fintastical Account, general updates, market updates and other marketing materials, including about the Services offered by members of the Fintastical Group;</li>
        <li>tailor the products and services offered through the Site to you, including without limitation, to perform any suitability or appropriateness assessments for using our services and/or products, such as our high-leveraged trading services and Social Trading Features;</li>
        <li>assess your credit risk;</li>
        <li>assess your risk score according to parameters determined by Fintastical;</li>
        <li>assess whether you qualify as a professional client, wholesale client or other specific category of client;</li>
        <li>maintain administrative records relating to our business;</li>
        <li>set up security measures to secure your account, including without limitation, to carry out two-factor authentication (“2FA”); and</li>
        <li>provide the Services.</li>
    </ul>
    <p>You can update your Profile at any time by visiting the “Account” page in the Settings menu when logged into your Fintastical Account. We recommend that you update your Profile regularly, to ensure that the Fintastical functions offered to you are appropriate for your current circumstances. You further agree to update such information upon Fintastical request, if Fintastical considers the information provided as untrue, incorrect, incomplete and/or inconsistent with other information provided by you at any time. You acknowledge that we may rely upon such information and that you are responsible for any damages or losses which may result from any inaccuracies, including without limitation, the inappropriateness of our Services to your Profile. You do not have to complete your Profile and therefore do not have to provide the information; however, if you choose not to, we will be unable to offer Fintastical’s full functionality to you.</p>

    <h4>When You Contact Us</h4>
    <p>If you contact us by telephone, email, post or use another function offered by Fintastical, such as the chat feature, we will collect any information about the communication and any additional information that you choose to give us. We will use this information to review, investigate and respond to any comment or question that you may raise. Please note that we record and retain all telephone calls and other communication with us and may use it in our dealings with you, including any dispute resolution or legal proceedings.</p>

    <h4>When a Fintastical User Invites You to Use Fintastical</h4>
    <p>Users of Fintastical can invite their contacts to sign up for an account with us. We only collect the email addresses of individuals that users choose to invite to join Fintastical and Fintastical only uses the email addresses for sending an invitation to the individual at the request of the existing Fintastical user.</p>

    <h3>Information About Your Use of the Fintastical Services</h3>
    <h4>Usage and Automatically Collected Information</h4>
    <p>When you access or use our Services, we automatically collect information about you (the type of information depends on the Site you are using), including:</p>
    <ul>
        <li><strong>Financial Information:</strong> We collect financial information related to your use of the Services, including information you provide to us or that we collect from public sources.</li>
        <li><strong>Log Information:</strong> We collect log information about your use of the Services, including the type of browser you use, app version, access times, pages viewed, your IP address, any other network identifiers, and the page you visited before navigating to our Services.</li>
        <li><strong>Device Information:</strong> We collect information about the computer or mobile device you use to access our Services, including the hardware model, operating system and version, unique device identifiers, and mobile network information.</li>
        <li><strong>Activities on the Site:</strong> We collect records of activities on the Site, including, any content you post, your Fintastical Account details, the time, value and currency of any deposit, withdrawal, or transaction made and the payment method.</li>
        <li><strong>Location Information:</strong> In accordance with your device permissions, we may collect information about the geo-location of your device.</li>
        <li><strong>Information Collected by Cookies and Other Tracking Technologies:</strong> We use different technologies to collect information, including cookies and web beacons. You can find out more about Fintastical’s use of cookies and similar technologies in our Cookie Policy.</li>
    </ul>
    <p>If you are a Fintastical Money customer, please also see the section “Fintastical Money” below.</p>

    <h3>Information We Collect from Other Sources</h3>
    <p>We may collect personal information about you from third party entities when we seek to verify your identity as part of our regulatory requirements. This may include, for example, identity verification agencies, credit referencing agencies and similar bodies. We may also collect information about you from third parties, when you use or connect to Fintastical by or through a third-party platform, such as Facebook or another site, you allow us to access and/or collect certain information from your third party platform profile/account as permitted by the terms of the agreement and your privacy settings with the third party platform. We will share such information with the third party platform for their use.</p>
    <p>Some of the information we collect from you on installation of the mobile app will be shared by us with vendors and other service providers who are engaged by, or working with, us in connection with operating and analyzing the Services we provide to you.</p>
    <p>If you are a Fintastical Money customer, please also see the section “Fintastical Money” below.</p>

    <h3>Unsolicited Information</h3>
    <p>If you provide us with personal information that we have not requested then we will endeavour to only retain the information that we are entitled or required to hold because of the products and services we provide. However, if this additional information is surplus to our requirements but is provided to us in a manner where it is combined with information that we are either required or entitled to retain then you acknowledge that this unsolicited information may be held by us in the same manner as the balance of your personal information.</p>

    <h2>Use of Information</h2>
    <p>We use the information we collect to provide, maintain, and improve the Services, such as to administer, verify and maintain your account, to provide the Services you request and customize your experience with us. We also use the information we collect to:</p>
    <ul>
        <li>carry out our obligations owed to you;</li>
        <li>comply with our regulatory and other legal obligations;</li>
        <li>monitor/access any content you post;</li>
        <li>administer transactions including deposits, chargebacks and payments;</li>
        <li>monitor trading activity on Fintastical, including by detecting inconsistencies in payments and trades and looking out for potentially illegal activities;</li>
        <li>determine whether a payment method is being abused;</li>
        <li>compile statistical analysis of the pages of our platform and websites;</li>
        <li>monitor and analyze our business;</li>
        <li>investigate and to manage enquiries, disputes and legal proceedings and to comply with court orders, mandatory dispute resolution determinations and mandatory government authority or law enforcement orders or directions;</li>
        <li>provide information about you and your trading with us to credit reference/reporting agencies;</li>
        <li>participate in crime prevention, legal and regulatory compliance and to assist regulatory, cybercrime, data and information protection agencies and police with their enquiries and enforcement, even if not compelled to do so;</li>
        <li>develop and to market other products and services; and</li>
        <li>novate, transfer or assign any of the rights or liabilities of the Fintastical Entity.</li>
    </ul>

    <h2>Sharing of Information</h2>
    <p>We will not share the personal information we hold about you except in the following circumstances:</p>
    <ul>
        <li>between and among the Fintastical Entity, Fintastical and our current and future parents, affiliates, subsidiaries, and other companies under common control and ownership; and</li>
        <li>with professional advisors, vendors, consultants, and other service providers, such as payment service providers, IT hosting companies, banks, other financial institutions and credit reporting/reference agencies who need access to such information to carry out work on our behalf;</li>
        <li>in connection with, or during negotiations of, any merger, sale of company assets, financing or acquisition of all or a portion of Fintastical by another company;</li>
        <li>disclosure in accordance with, or required by, any applicable law or legal process, including lawful requests by public authorities to meet national security or law enforcement requirements;</li>
        <li>if we believe your actions are inconsistent with our user agreements or policies, or to protect the rights, property, and safety of Fintastical or others; or.</li>
        <li>where we have your consent. For example, if you use the “Fintastical Connect” feature, we will get your permission before sharing your personal information with a third party.</li>
    </ul>
    <p>If you are a Fintastical Money customer, please also see the section “Fintastical Money” below.</p>

    <h2>Social Sharing Features</h2>
    <p>If you have elected to use one of our applications provided via social networks (such as Facebook, Twitter, etc.), our application will be granted access to your social network account general information which includes your name and username in the social network, profile picture, gender, networks, user ID, list of friends, and any other information you have permitted to be shared depending on the settings you establish with the entity that provides the social sharing feature. For more information about the purpose and scope of data collection and processing in connection with social sharing features, please visit the privacy policies of the entities that provide these features.</p>

    <h2>Advertising and Analytics Services Provided by Others</h2>
    <p>We may allow others to provide analytics services and serve advertisements about our products and services on our behalf across the web and in mobile applications. This may involve cookies and other technologies to collect information about your use of the Services. This information may be used by Fintastical to, among other things, analyze and track data, determine the popularity of certain content, deliver advertising and content targeted to your interests on our Services, and better understand your online activity in connection with the Services. Please refer to our Cookie Policy for more information about the cookies involved and the process of consenting or refusing cookies. For more information about interest-based ads generally, please visit <a href="http://www.aboutads.info/choices">www.aboutads.info/choices</a> if you are in the United States and if you are in the EU or the UK, please visit <a href="http://www.youronlinechoices.eu/">www.youronlinechoices.eu/</a>.</p>

    <h2>Your Choices and Rights</h2>
    <p>You may have certain rights and protections under the law regarding the processing of your personal data. For example, you may also have the right to object to, or request that we restrict, certain processing and in some circumstances to obtain a copy of the personal information in machine readable format. There are limits to such rights where they apply and in certain circumstances we may not be required or able to meet your request, or we may only meet your request in part.</p>

    <h3>Legal Basis for Processing</h3>
    <p>For transparency purposes (where relevant under data protection legislation applicable to our processing of your personal information) we process your personal data on the following legal grounds:</p>
    <ul>
        <li><strong>Entering into and Performing the Contract with You:</strong> If you have a Fintastical Account or have registered on the Site or for the Services, our legal basis for processing your personal information is that it is necessary for the performance of the relevant Fintastical Entity’s terms and conditions, terms of business and/or terms of use, and to provide the requested service to you. With respect to a Fintastical Account, this includes facilitating access to our platform, processing payments and executing trades.</li>
        <li><strong>For other Justifiable Grounds, including Legal Obligation and Legitimate Interests:</strong> We process your personal information where necessary for Fintastical to comply with legal and regulatory obligations we are under, and also where it is necessary for legitimate interests we have in conducting our business</li> </ul> </div>
</template>

<style scoped>
.privacy-container {
  padding: 20px;
  max-width: 800px;
  margin: auto;
}
</style>
