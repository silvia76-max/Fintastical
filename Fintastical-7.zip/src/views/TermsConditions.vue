<template>
  <div class="conditions-container">
    <h1>Fintastical Futures Risk Disclosures</h1>

<p>Investment products offered by Fintastical include stocks, Exchange-Traded Funds (ETFs), and cryptocurrencies, in which you gain ownership of the underlying asset. In addition, Fintastical offers contracts for differences (CFDs) that offer exposure to currencies, commodities, and indices.</p>

<p>Any transactions relating to stocks, ETFs, or cryptocurrencies in which Fintastical offers you leverage (which is not currently available for cryptocurrencies) or allows you to enter into short transactions, and/or some copy trading transactions (including Smart Portfolios), shall be considered CFD transactions.</p>

<p>Fintastical also offers investors the opportunity to buy the underlying cryptocurrencies, stocks, or ETFs (i.e., BUY transactions for said assets using leverage) 1) hold such assets and subsequently sell such assets. All transactions relating to cryptocurrencies are subject to the Cryptocurrencies Trading Addendum (“Cryptocurrencies Trading Addendum”).</p>

<p>Since cryptocurrency markets are decentralized and non-regulated, our Cryptocurrencies Trading Services, as such term is defined in the Cryptocurrencies Trading Addendum, are unregulated services which are not governed by any specific European regulatory framework (including MIFID). Therefore, when Fintastical (Europe) Ltd. customers use our Cryptocurrencies Trading Service, they will not benefit from the protections available to clients receiving regulated investment services such as access to the Investor Compensation Fund for Customers of Cypriot Investment Firms and the UK Financial Ombudsman Service for dispute resolution. Fintastical (Europe) Ltd. customers will continue to benefit from the rules relating to best execution and client money and safekeeping of client assets. Fintastical (UK) Ltd. customers using the Cryptocurrencies Trading Service only will not benefit from the protections available to clients receiving regulated investment services such as access to the Financial Services Compensation Scheme (FSCS) and the Financial Ombudsman Service for dispute resolution. We will endeavor to enable you to benefit from rules relating to best execution and safekeeping of client assets.</p>

<p class="disclaimer">All of these products carry a high degree of risk and are not suitable for many investors. This notice provides you with information about the risks associated with these products, but it cannot explain all of the risks nor how such risks relate to your personal circumstances. If you are in doubt, you should seek professional advice. It is important that you fully understand the risks involved before deciding to trade with Fintastical, that you have adequate financial resources to bear such risks, and that you monitor your positions carefully. Trading involves risk to your capital. You should not invest money that you cannot afford to lose; however, you cannot lose more than the equity in your account.</p>

<p class="disclaimer">NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THE TERMS AND CONDITIONS AND/OR THIS GENERAL RISK DISCLOSURE, FRENCH RESIDENTS SHALL BE ELIGIBLE TO INTRINSIC PROTECTION. ACCORDINGLY, AND INDEPENDENTLY OF MARKET VOLATILITY, THEIR MAXIMUM LOSS WITH RESPECT TO EACH TRANSACTION SHALL BE THE TOTAL AMOUNT INVESTED IN SUCH TRANSACTION, AS UPDATED BY SUCH USER FROM TIME TO TIME.</p>

<div class="section-title">CFDs</div>
<p>CFD stands for “Contract For Difference,” meaning you are not buying the underlying asset, but rather purchasing a contract to settle the difference in the initial and ending price of the asset. When trading CFDs, you generally trade on margin, which means you only have to deposit a small percentage of the overall value of your position. This is known as “Leverage,” and even small market movements may have great impact, negative or positive, on your trading account.</p>

<p>If the market moves against you, you may sustain a total loss greater than the funds invested in a specific position. You are responsible for all losses in your account up to the equity in your account.</p>

<p>Before deciding to trade on margin, you should carefully consider your investment objectives, level of experience, and risk appetite. Our CFDs are not listed on any exchange. CFDs involve greater risk than investing in on-exchange products, as market liquidity cannot be guaranteed, and it may be more difficult to liquidate an existing position. The prices and other conditions are set by us in accordance with our obligation to provide best execution as set out in our order execution policy, to act reasonably and in accordance with the applicable Terms and Conditions. The characteristics of our CFDs can vary substantially from the actual underlying market or instrument. Full details of all of our CFDs are set out on our website. In respect of corporate events, with respect to the underlying assets, we do not aim to make a profit from our clients from the outcome of corporate events such as rights issues, takeovers, mergers, share distributions, or consolidations and open offers. We aim to reflect the treatment we receive, or would receive if we were hedging our exposure to you in the underlying market. Ultimately, however, you are not dealing in the underlying market, and therefore, in relation to our CFDs, the treatment you receive may be less advantageous than if you owned the underlying instrument.</p>

<p class="disclaimer">CFDs are complex instruments and come with a high risk of losing money rapidly due to leverage. 74% of retail investor accounts lose money when trading CFDs with this provider. You should consider whether you understand how CFDs work, and whether you can afford to take the high risk of losing your money.</p>

<p>CFDs are not suited to the long-term investor. If you hold a CFD open over a long period, the associated costs increase (such as overnight fees), and it may be more beneficial for you to buy the underlying asset instead. Sudden market movements, known as “gapping,” may occur, causing a dramatic shift in the price of an underlying asset. Gapping may occur when the underlying market is closed, meaning the price on the underlying market may open at a significantly different level, and at a less advantageous price for you.</p>

<p>At all times during which you have open positions, you must ensure that your account meets our margin requirements, which may change from time to time. Therefore, if our price moves against you, or if our margin requirements have changed, you may need to provide us with significant additional funds to meet your margin requirement at short notice to maintain your open positions. If you do not do this, we will be entitled to close one or more or all of your positions, and you alone will be responsible for any losses incurred as a result.</p>

<div class="section-title">Appropriateness</div>
<p>Before we open an account for you, we are required to make an assessment of whether the product(s) and/or services you have chosen are appropriate for you, and to warn you if, on the basis of the information you provide us, any product or service is not appropriate. If you decide to continue and open an account with us, you are confirming that you are aware of and understand the risks.</p>

<div class="section-title">Position Monitoring</div>
<p>You should further ensure that you are able to monitor positions on your account at all times, as you are solely responsible for this. We are not responsible for monitoring positions on your account.</p>

<div class="section-title">Execution</div>
<p>Although the Fintastical trading platform is automated, and we give you the best execution available, it is possible that the market price could have changed between order placement and execution time, and therefore, we cannot guarantee that the price requested will be the same as the price at which the order is executed. Therefore, the price you receive can be in your favor or against you.</p>

<p>To limit losses, we require you to choose ‘stop loss’ limits. These set limits to automatically close your position when it reaches a price limit of your choice. There are, however, circumstances in which a ‘stop loss’ limit is not fully effective — for example, where there are rapid price movements or market closure.</p>

<p>In addition, there are risks associated with the use of online deal execution and trading systems, including, but not limited to, software and hardware failure and internet disconnection.</p>

<div class="section-title">Copy Trading</div>
<p>Fintastical offers Social Trading Features. In making a decision to copy a specific trader or traders and/or follow a particular strategy, you must consider your entire financial situation, including financial commitments. You must understand that using Social Trading Features is highly speculative and that you could sustain significant losses exceeding the amount used to copy a trader or traders. The risks associated with Social Trading Features include, but are not limited to, automated trading execution whereby the opening and closing of trades will happen in your account without your manual intervention.</p>

<p>You can read more about copy trading risks here.</p>

<div class="section-title">Cryptocurrencies</div>
<div class="section-title">Trading Risks</div>
<p>Since cryptocurrency markets are decentralized and non-regulated, our Cryptocurrencies Trading Services are unregulated services that are not governed by any specific European regulatory framework (including MIFID). This means that there is no central bank that can take corrective measures to protect the value of cryptocurrencies in a crisis or issue more currency. Therefore, when Fintastical (Europe) Ltd. customers use our Cryptocurrencies Trading Services, they will not benefit from the protections available to clients receiving regulated investment services such as access to the Investor Compensation Fund for Customers of Cypriot Investment Firms and the Financial Ombudsman Service for dispute resolution. Fintastical (Europe) Ltd. customers will continue to benefit from the rules relating to best execution and client money and safekeeping of client assets.</p>

<p>Fintastical (UK) Ltd. customers using Cryptocurrencies Services will not benefit from the protections available to clients receiving regulated investment services such as access to the Financial Services Compensation Scheme (FSCS) and the Financial Ombudsman Service for dispute resolution. We will endeavor to enable you to benefit from rules relating to best execution and safekeeping of client assets.</p>

<p><strong>Cryptocurrency markets are determined by demand and supply only.</strong> The cryptocurrency market is a dynamic arena, and its respective prices are often highly unpredictable and volatile. Cryptocurrency prices are usually not transparent, highly speculative, and susceptible to market manipulation. In the worst-case scenario, the product could be rendered worthless.</p>

  </div>
</template>

<style scoped>
.conditions-container {
  padding: 20px;
  max-width: 800px;
  margin: auto;
}
</style>
