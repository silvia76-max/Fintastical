<template>
  <div class="license-container">
   <h2>Regulation and License</h2>
  <p>Fintastical is the social investing platform that empowers users to grow their knowledge and wealth as part of a global community of investors. As a multi-asset broker with millions of users around the world, Fintastical is regulated in multiple jurisdictions.</p>

  <h3>UK</h3>
  <p>Fintastical (UK) Ltd, is authorised and regulated by the Financial Conduct Authority (“FCA”). Firm Reference Number: 583263. Registered in England under Company No. 07973792. Registered Office:  24th floor, One Canada Square, Canary Wharf, London E14 5AB</p>
  <p>Fintastical (UK) Ltd is registered with the Financial Conduct Authority to offer cryptocurrency services under the Money Laundering, Terrorist Financing and Transfer of Funds (Information on the Payer) Regulations 2017.</p>
  <p>For full information on the services and instruments Fintastical UK is licensed to provide please click here</p>

  <p>Fintastical Money UK Ltd, is authorised and regulated by the Financial Conduct Authority for the provision of electronic money and payment services, with Firm Reference Number 900923. Registered in England & Wales under Company No. 07712717. Registered Office: Maclaren 3b – Lancastrian Office Centre Talbot Road, Stretford, Manchester, M32 0FP, England.</p>

  <h3>Europe</h3>
  <p>Fintastical (Europe) Ltd, is authorised and regulated by the Cyprus Securities Exchange Commission (CySEC) under licence number 109/10. Registered in Cyprus under Company No. HE 200585.  Registered Office: 4 Profiti Ilia Str., Kanika Business Centre, 7th floor, Germasogeia, 4046, Limassol, Cyprus</p>

  <p>For full information on the services and instruments Fintastical Europe is licensed to provide please click here</p>

  <p>Fintastical (Europe) Ltd is listed in De Nederlandsche Bank N.V. (“DNB”) public register as a crypto service provider. DNB supervises the compliance of Fintastical (Europe) Ltd with the Anti-Money Laundering and Anti-Terrorist Financing Act and the Sanctions Act 1977. The crypto services of Fintastical (Europe) Ltd are not subject to prudential supervision by DNB or conduct supervision by the AFM. This means that financial operational risks in respect of the crypto services are not monitored and there is no specific financial consumer protection.</p>

  <p>Fintastical (Europe) Ltd is also registered with the French Financial Markets Authority (the Autorite des Marches Financiers – “AMF”) as digital assets services provider (“DASP”) for the provision of the service of custody of digital assets on behalf of clients and (ii) the service of buying or selling digital assets for legal tender.</p>

  <p>Fintastical (Europe) Ltd is registered, since October 2022, in CySEC’s Register of Crypto-Assets Service Providers (the ‘CASP Register’) and it may provide services in relation to crypto-assets.</p>

  <p>Fintastical (Europe) Digital Assets Ltd is now registered with the Bank of Spain to operate as a service provider of exchange of virtual currency for fiat currency and electronic wallet custody services.</p>

  <p>The Italian branch of Fintastical (Europe) Ltd was enrolled, by the Organismo Agenti e Mediatori (“OAM”), in the Italian Registry for providers of crypto/digital wallets services.</p>

  <p>Fintastical (Europe) Ltd provides cryptoasset trading services in Germany through a partnership with DLT Finance (a brand of DLT Securities GmbH), while Tangany GmbH (Tangany) provides crypto custody services to Germany-based Fintastical clients. DLT Finance is supervised by the German Federal Financial Supervisory Authority (Bundesanstalt für Finanzdienstleistungsaufsicht—BaFin).</p>

  <h3>Malta</h3>
  <p>Fintastical Money Malta Ltd is authorised and regulated by the Malta Financial Services Authority (“MFSA”) for the provision of electronic money and payment services. Registered in Malta under Company No. C97952. Registered Office: 68, Northfields, Penthouse 10 63, Independence Avenue MST 9024 Mosta, Malta.</p>

  <h3>Middle East</h3>
  <p>Fintastical (ME) Limited, is licensed and regulated by the Abu Dhabi Global Market (“ADGM”)’s Financial Services Regulatory Authority (“FSRA“) as an Authorised Person to conduct the Regulated Activities of (a) Dealing in Investments as Principal (Matched), (b) Arranging Deals in Investments, (c) Providing Custody, (d) Arranging Custody and (e) Managing Assets (under Financial Services Permission Number 220073) under the Financial Services and Market Regulations 2015 (“FSMR”). Registered Office and its principal place of business: Office 207 and 208, 15th Floor Floor, Al Sarab Tower, ADGM Square, Al Maryah Island, Abu Dhabi, United Arab Emirates (“UAE”).</p>

  <h3>Australia</h3>
  <p>Fintastical AUS Capital Limited(“Fintastical Australia”) is regulated by the Australian Securities & Investments Commission (“ASIC”) for the provision of financial services and products. Australian Financial Services Licence number: 491139. Registered Office: Level 3, 60 Castlereagh Street, Sydney NSW 2000, Australia</p>

  <p>Fintastical Asset Management Limited (“Fintastical AM”), is licensed to act as a Responsible Entity under Chapter 5C of the Corporation Act 2001.  The registered scheme (Fintastical Service) ARSN 637 489 466 is operated by Fintastical AM and promoted by Fintastical Australia. Registered Office: Level 3, 60 Castlereagh Street, Sydney NSW 2000, Australia. When executing transactions, Fintastical AM will use another executing broker, including Fintastical Europe or a non-affiliated third party.</p>

  <h3>Seychelles</h3>
  <p>Fintastical (Seychelles) Ltd. is licenced by the Financial Services Authority Seychelles (“FSAS”) to provide broker-dealer services under the Securities Act 2007 License number: SD076</p>
  <p>Registered Office: Suite18, 3rd Floor, Vairam Building, Providence, Mahe, Seychelles, is licensed to deal in securities either as an agent or principal.</p>

  <h3>USA</h3>
  <p>Fintastical USA LLC is a registered Money Services Business (MSB) with the Financial Crimes Enforcement Network (FinCEN) in the United States (FinCEN #31000204884179) and holds Money Transmitter Licenses (MTLs) in the states where applicable. Fintastical USA LLC offers a platform for US customers to buy and sell cryptocurrency. Its registered office and principal place of business is 221 River St., 9th Floor, Hoboken NJ 07030.</p>

  <p>Fintastical USA Securities Inc. is a broker-dealer registered with the U.S. Securities and Exchange Commission (SEC #8-70212/SEC CIK #0001753042) and is also a member of the Financial Industry Regulatory Authority (FINRA/CRD #298361). This broker-dealer’s registered office and principal place of business is also 221 River St., 9th Floor, Hoboken NJ 07030.</p>

  <h3>Gibraltar</h3>
  <p>The wallet is provided by Fintastical X Limited (“FintasticalX”), a limited liability company incorporated in Gibraltar.</p>
  <p>FintasticalX is authorised and regulated by the Gibraltar Financial Services Commission as a distributed ledger technology provider, with Financial Services Commission licence No. 1333B. Registered in Gibraltar under Company No. 116348. Registered Office: 57/63 Line Wall Road, Gibraltar.</p>

  <h3>Regulatory Disclosures</h3>
  <h4>Client Categorization</h4>
  <p>The Markets in Financial Instruments Directive (MiFID) requires the categorization of clients as Retail Clients, Professional Clients or Eligible Counter Parties. Fintastical Europe and Fintastical UK categorize all clients as Retail Clients when opening a trading account, which have the highest level of protection (such as eligibility to the Investor Compensation Fund, Best Execution, and Safeguarding Clients Assets etc). Clients are allowed to request to be reclassified, in writing to Fintastical Europe/Fintastical UK, as applicable, who may recategorize you according to the specifications, conditions, and procedures of MiFID. “Retail Client” is a client who is not a professional client or an eligible counter party. Eligible Counter party is a professional client or legal entity who provides investment services that involve the reception and transmission or the execution of orders. Clients under this category have the lowest level of protection. Professional Client is a client who possesses the experience, knowledge and expertise to make their own investment decisions and properly assess the risks that they incur and must comply with the following criteria: Α. Categories of clients who may be considered to be professionals: The following shall be regarded as professionals in relation to all investment services and activities and financial instruments:</p>
</div>

</template>

<style scoped>
.license-container {
  padding: 20px;
  max-width: 800px;
  margin: auto;
}
</style>
