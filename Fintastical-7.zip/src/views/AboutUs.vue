<template>
  <div class="about-us">
    <h1>About Us</h1>
    <p>
      Welcome to Fintastic, your trusted partner in financial management and personal finance. At Fintastic, we empower individuals and businesses to take control of their financial future through innovative tools, expert insights, and personalized solutions. Whether you're looking to manage your investments, track your expenses, or plan for long-term financial goals, Fintastic is here to guide you every step of the way. Join us and discover a smarter, simpler, and more secure way to manage your finances.
    </p>
    <p>
      Our mission at Fintastic is to democratize access to financial tools and knowledge, enabling everyone to make informed decisions about their money. We strive to provide a seamless and intuitive platform that simplifies financial management, from budgeting and saving to investing and wealth growth. By combining cutting-edge technology with expert financial advice, we aim to help our users achieve financial stability, independence, and success
    </p>
    <p>
      At Fintastic, we envision a world where everyone has the tools and confidence to achieve their financial dreams. We aim to be the leading global platform for personal finance and asset management, recognized for our innovation, transparency, and commitment to our users' success. Through continuous improvement and a user-centric approach, we aspire to transform the way people interact with their finances, making financial freedom accessible to all.
    </p>
  </div>
</template>

<script>
export default {
  name: 'about-us',
}
</script>

<style scoped>
.about-us {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  text-align: center;
}

.about-us h1 {
  font-size: 2.5rem;
  margin-bottom: 20px;
}

.about-us p {
  font-size: 1.1rem;
  line-height: 1.6;
  margin-bottom: 15px;
}
</style>
